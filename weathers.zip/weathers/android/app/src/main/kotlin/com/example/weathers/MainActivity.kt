package com.example.weathers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
