// weather_details_page.dart

// ignore_for_file: prefer_const_constructors, library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:weathers/services/weather_model.dart';
import 'package:weathers/services/weather_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WeatherDetailsPage extends StatefulWidget {
  final String searchQuery;

  const WeatherDetailsPage({Key? key, required this.searchQuery})
      : super(key: key);

  @override
  _WeatherDetailsPageState createState() => _WeatherDetailsPageState();
}

class _WeatherDetailsPageState extends State<WeatherDetailsPage> {
  late WeatherService _weatherService;
  Weather? _weather;
  bool _isLoading = true;
  String _errorMessage = '';


// fetching weather details of searched city(searchQuery) using _fetchWeather()
  @override
  void initState() {
    super.initState();
    _weatherService = WeatherService();
    _fetchWeather();
  }

// Finding weather of searchQuery city and saving it in shared preference.
  Future<void> _fetchWeather() async {
    try {
      Weather weather = await _weatherService.fetchWeather(widget.searchQuery);
      setState(() {
        _weather = weather;
        _isLoading = false;
        _errorMessage = ''; // Clear error message on successful fetch
      });

      // Save weather data to shared preferences
      _saveWeatherToSharedPreferences(widget.searchQuery,weather);
    } catch (e) {
      setState(() {
        _isLoading = false;
        _weather = null;
        _errorMessage =
            e.toString(); // Display error message received from WeatherService
      });
    }
  }

  Future<void> _saveWeatherToSharedPreferences(String cityName,Weather weather) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Save weather data
    prefs.setString('cityName', cityName);
    prefs.setDouble('temperature', weather.temperature);
    prefs.setString('condition', weather.condition);
    prefs.setString('iconUrl', weather.iconUrl);
    prefs.setInt('humidity', weather.humidity);
    prefs.setDouble('windSpeed', weather.windSpeed);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: <Widget>[
          GestureDetector(
              onTap: () {
                setState(() {
                  _fetchWeather();
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Refreshed'),
                    duration: Duration(seconds: 2), // Adjust duration as needed
                  ),
                );
              },
              child: Icon(Icons.refresh))
        ],
        centerTitle: true,
        title: Text(widget.searchQuery),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _weather != null
              ? Stack(
                  fit: StackFit.expand,
                  children: <Widget>[
                    // Background image
                    Image.asset(
                      'assets/background.jpg',
                      fit: BoxFit.cover,
                    ),
                    // Weather data
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          _weather!.iconUrl.isNotEmpty
                              ? Container(
                                  height: 150,
                                  width: 150,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: NetworkImage(
                                            _weather!.iconUrl,
                                          ),
                                          fit: BoxFit.cover)),
                                  child: Text(""),
                                )
                              : Icon(Icons.error_outline,
                                  size: 200, color: Colors.white),
                          SizedBox(height: 1.0),
                          Text(
                            '${_weather!.temperature.toStringAsFixed(1)}°C',
                            style: TextStyle(
                                fontSize: 32.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          SizedBox(height: 20.0),
                          Text(
                            _weather!.condition,
                            style:
                                TextStyle(fontSize: 24.0, color: Colors.white),
                          ),
                          SizedBox(height: 20.0),
                          Text(
                            'Humidity: ${_weather!.humidity}%',
                            style:
                                TextStyle(fontSize: 20.0, color: Colors.white),
                          ),
                          SizedBox(height: 20.0),
                          Text(
                            'Wind Speed: ${_weather!.windSpeed} m/s',
                            style:
                                TextStyle(fontSize: 20.0, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              : Center(
                  child: Text(
                    _errorMessage.isNotEmpty
                        ? _errorMessage
                        : 'No weather data found.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18.0, color: Colors.red),
                  ),
                ),
    );
  }
}
