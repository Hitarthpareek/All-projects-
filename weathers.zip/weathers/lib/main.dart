// ignore_for_file: prefer_const_constructors
// Home page
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:weathers/pages/secondpage.dart'; // Adjust import as necessary

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home:
          const MyAppHome(), // Use a separate StatelessWidget for home for clarity
    );
  }
}

class MyAppHome extends StatefulWidget {
  const MyAppHome({Key? key}) : super(key: key);

  @override
  _MyAppHomeState createState() => _MyAppHomeState();
}

class _MyAppHomeState extends State<MyAppHome> {
  final TextEditingController controller = TextEditingController();
  String searchQuery = "";

// varables used for displaying shared preferences variables
  String cityName = "";
  double temperature = 0.0;
  String condition = "";
  String iconUrl = "";
  int humidity = 0;
  double windSpeed = 0.0;

// Onclick of search button, heading to secondPage with a non empty string and after poping from that state refreshing most recent weather city searched on home page
  void performSearch(BuildContext context) {
    if (controller.text.isNotEmpty) {
      setState(() {
        searchQuery = controller.text;
      });
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => WeatherDetailsPage(searchQuery: searchQuery),
        ),
      ).then((value) {
        setState(() {
          _loadSavedWeatherItems();
        });
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Enter a city name'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

// In init state, using this function to load shared preference data from device when app starts
  Future<void> _loadSavedWeatherItems() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Retrieve saved weather items using consistent keys
    cityName = prefs.getString('cityName') ?? 'Search City';
    temperature = prefs.getDouble('temperature') ?? 0.0;
    condition = prefs.getString('condition') ?? 'NA';
    iconUrl = prefs.getString('iconUrl') ?? '';
    humidity = prefs.getInt('humidity') ?? 0;
    windSpeed = prefs.getDouble('windSpeed') ?? 0.0;

    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _loadSavedWeatherItems();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Image.asset('assets/weatherforec.jpg'),
        title: const Text("Weather App"),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              TextField(
                controller: controller,
                decoration: const InputDecoration(
                  labelText: 'Enter City Name',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  performSearch(context); // Pass context here
                },
                child: const Text('Search'),
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Text(
                    'Recently Searched',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Text(cityName == ""
                        ? "Search City"
                        : cityName), // Replace with dynamic content as needed
                  ),
                ],
              ),
              // if (iconUrl.isNotEmpty)
              //   Image.network(
              //     iconUrl,
              //     width: 100,
              //     height: 100,
              //     fit: BoxFit.cover,
              //   ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  _buildWeatherItem(
                    title: 'Temperature',
                    value: '$temperature °C',
                  ),
                  _buildWeatherItem(
                    title: 'Condition',
                    value: condition == "" ? "NA" : condition,
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  _buildWeatherItem(
                    title: 'Humidity',
                    value: '$humidity %',
                  ),
                  _buildWeatherItem(
                    title: 'Wind Speed',
                    value: '$windSpeed m/s',
                  ),
                ],
              ),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Refreshed'),
                        duration:
                            Duration(seconds: 2), // Adjust duration as needed
                      ),
                    );
                    _loadSavedWeatherItems();
                  });
                },
                child: const Text('Refresh'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWeatherItem({required String title, required String value}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }
}
