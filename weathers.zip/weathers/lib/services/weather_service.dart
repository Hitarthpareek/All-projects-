// openWeatherMap api services to receive data from API
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'weather_model.dart';

class WeatherService {
  final String apiKey = '30c049b50732d4a4e472677aa7971989'; // Replace with your actual API key
  final String apiUrl = 'https://api.openweathermap.org/data/2.5/weather';

  Future<Weather> fetchWeather(String city) async {
    final response = await http.get(Uri.parse('$apiUrl?q=$city&units=metric&appid=$apiKey'));

    if (response.statusCode == 200) {
      // Check if response body is empty
      if (response.body.isEmpty) {
        throw Exception('No weather data found for $city');
      }

      // Parse JSON
      final jsonData = jsonDecode(response.body);
      return Weather.fromJson(jsonData);
    } else if (response.statusCode == 404) {
      throw Exception('City not found. Please enter a valid city name.');
    } else {
      throw Exception('Failed to load weather data');
    }
  }
}

