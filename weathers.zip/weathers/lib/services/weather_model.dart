// Data model for retriving data from API

class Weather {
  final double temperature;
  final String condition;
  final String iconUrl;
  final int humidity;
  final double windSpeed;

  Weather({
    required this.temperature,
    required this.condition,
    required this.iconUrl,
    required this.humidity,
    required this.windSpeed,
  });

  factory Weather.fromJson(Map<String, dynamic> json) {
    return Weather(
      temperature: json['main']['temp'].toDouble(),
      condition: json['weather'] != null && json['weather'].isNotEmpty
          ? json['weather'][0]['main']
          : 'Unknown',
      iconUrl: json['weather'] != null && json['weather'].isNotEmpty
          ? 'https://openweathermap.org/img/wn/${json['weather'][0]['icon']}.png'
          : '',
      humidity: json['main']['humidity'],
      windSpeed: json['wind']['speed'].toDouble(),
    );
  }
}
