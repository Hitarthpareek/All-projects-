package com.example.summary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
