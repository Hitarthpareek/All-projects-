import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:summary/models/article.dart';

// const String TODO_COLLECTON_REF = "userdata";

// class DatabaseService {
//   final _firestore = FirebaseFirestore.instance;

//   late final CollectionReference _todosRef;

//   DatabaseService() {
//     _todosRef =
//         _firestore.collection(TODO_COLLECTON_REF).withConverter<Article>(
//             fromFirestore: (snapshots, _) => Article.fromJson(
//                   snapshots.data()!,
//                 ),
//             toFirestore: (todo, _) => todo.toJson());
//   }

//   Stream<QuerySnapshot> getTodos() {
//     return _todosRef.snapshots();
//   }

//   void addTodo(Article todo) async {
//     _todosRef.add(todo);
//   }

//   void deleteTodo(String todoId) {
//     _todosRef.doc(todoId).delete();
//   }
// }

const String TODO_COLLECTON_REF = "useracc";

class DatabaseService {
  late CollectionReference<Article> _todosRef;
  late FirebaseAuth _auth;
  final firestore = FirebaseFirestore.instance;

  DatabaseService() {
    _auth = FirebaseAuth.instance;
    _todosRef = firestore.collection(TODO_COLLECTON_REF).withConverter<Article>(
        fromFirestore: (snapshots, _) => Article.fromJson(
              snapshots.data()!,
            ),
        toFirestore: (todo, _) => todo.toJson());
  }

  Future<String?> getCurrentUserId() async {
    final user = _auth.currentUser;
    if (user != null) {
      return user.uid;
    } else {
      return null;
    }
  }

  Future<void> addTodo(String? title, Article todo) async {
    final userId = await getCurrentUserId();
    if (userId != null) {
      // Create a collection named after the userId
      CollectionReference userCollection = firestore.collection(userId);

      // Add the todo document with title as the document ID
      await userCollection.doc(title).set(todo.toJson());
    }
  }

  // Stream<QuerySnapshot> getTodos() {
  //   return _todosRef.snapshots();
  // }
  Stream<QuerySnapshot> getTodos() async* {
    final userId = await getCurrentUserId();
    if (userId != null) {
      yield* firestore.collection(userId).snapshots();
    }
  }

  //  void addTodo(String? todoId, Article todo) async {
  //   await _todosRef.doc(todoId).set(todo);

  // }

  Future<void> deleteTodo(Article todo) async {
    final userId = await getCurrentUserId();
    if (userId != null) {
      await firestore.collection(userId).doc(todo.title!).delete();
    }
  }

  
}
