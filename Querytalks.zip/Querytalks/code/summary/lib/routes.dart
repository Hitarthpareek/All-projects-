class Myroutes {
  static String login = "/login";
  static String prehome = "/prehome";
  static String home = "/home";
  static String signup = "/signup";
  static String forgotpassword = "/forgotpassword";
  static String search = "/search";
  static String last30days = "/last30days";
}
