import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:summary/consts.dart';
import 'package:summary/database_service.dart';
import 'package:summary/models/article.dart';
import 'package:translator/translator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

class Bookmark extends StatefulWidget {
  const Bookmark({key});

  @override
  State<Bookmark> createState() => _BookmarkState();
}

class _BookmarkState extends State<Bookmark> {
  String dropdownvalue = 'English';
  String translated = '';
  var items = [
    'English',
    'Hindi',
    'Tamil',
  ];

  String mytext = '';
  bool scanning = false;
  bool isplaying = true;
  final DatabaseService _databaseService = DatabaseService();
  final FlutterTts flutterTts = FlutterTts();
  final apiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=AIzaSyB8B4g4U9V0rktuznItJdifAAtZO042f0c';

  final headers = {
    'Content-Type': 'application/json',
  };

  List<Article> bookarticles = [];

  void translate(String desti) async {
    GoogleTranslator translate = new GoogleTranslator();
    var translation = await translate.translate(mytext, from: 'en', to: desti);
    setState(() {
      mytext = translation.text.toString();
    });
  }

  String getlanguagecode(String lan) {
    if (lan == 'English')
      return "en-US";
    else if (lan == 'Hindi')
      return 'hi';
    else if (lan == 'Tamil') return 'ta';
    return '--';
  }

  getdata(Article article) async {
    setState(() {
      scanning = true;
    });
    print(article.content);

    var data = {
      "contents": [
        {
          "parts": [
            {'text': "Summarize in 30 words - ${article.content}"}
          ]
        }
      ],
    };

    await http
        .post(Uri.parse(apiUrl), headers: headers, body: jsonEncode(data))
        .then((response) {
      if (response.statusCode == 200) {
        var result = jsonDecode(response.body);

        print(result['candidates'][0]['content']['parts'][0]['text']);
        //setState(() {

        setState(() {
          mytext = mytext +
              "Title is : " +
              article.title! +
              ", and Summary is :" +
              result['candidates'][0]['content']['parts'][0]['text'];
        });
        speak(mytext, getlanguagecode(dropdownvalue));
        // });

        setState(() {
          scanning = false;
        });
      } else {
        print("request failed with status: ${response.statusCode}");
      }
    }).catchError((error) {
      print('Error : $error');
    });
  }

  Future<void> _launchUrl(Uri url) async {
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  speak(String text, String lan) async {
    if (!isplaying) {
      await flutterTts.setLanguage(lan);
      await flutterTts.setPitch(1);
      flutterTts.setSpeechRate(0.4);
      await flutterTts.speak(text);
    } // else {
    //   flutterTts.pause();
    // }
  }

  Future<List<Article>> fetchArticles() async {
    QuerySnapshot snapshot =
        await _databaseService.getTodos().first; // Take the first snapshot
    List<Article> articles = snapshot.docs.map((doc) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      return Article.fromJson(
          data); // Assuming you have a method to convert map to Article object
    }).toList();
    setState(() {
      bookarticles = articles;
    });
    return articles;
  }

  @override
  void initState() {
    // TODO: implement initState
    fetchArticles();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // actions: <Widget>[
        //   DropdownButton(
        //     padding: EdgeInsets.all(8),

        //     // Initial Value
        //     value: dropdownvalue,

        //     // Down Arrow Icon
        //     icon: const Icon(Icons.keyboard_arrow_down),

        //     // Array list of items
        //     items: items.map((String items) {
        //       return DropdownMenuItem(
        //         value: items,
        //         child: Text(items),
        //       );
        //     }).toList(),
        //     // After selecting the desired option,it will
        //     // change button value to selected value
        //     onChanged: (String? newValue) {
        //       setState(() {
        //         dropdownvalue = newValue!;
        //         translate(getlanguagecode(dropdownvalue));
        //       });
        //     },
        //   ),
        // ],
        centerTitle: true,
        title: Text(
          "Bookmarks",
          style: TextStyle(fontFamily: 'Pacifico', fontSize: 28),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        label: Text("Play"),
        backgroundColor: Colors.white,
        onPressed: () {
          setState(() {
            isplaying = !isplaying;
          });
          if (!isplaying) {
            for (int i = 0; i < bookarticles.length; i++) {
              getdata(bookarticles[i]);
            }
          } else {
            flutterTts.pause();
            setState(() {
              mytext = '';
            });
          }
        },
        icon: scanning
            ? Icon(Icons.circle)
            : Icon(
                isplaying ? Icons.play_arrow : Icons.volume_up,
                color: Color.fromARGB(255, 17, 0, 84),
              ),
      ),
      body: Container(
        child: Column(
          children: [
            StreamBuilder<QuerySnapshot>(
              stream: _databaseService.getTodos(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  // Cast snapshot.data to QuerySnapshot<Article>
                  // QuerySnapshot<Article> querySnapshot =
                  //     snapshot.data as QuerySnapshot<Article>;

                  // // Extracting list of articles from the snapshot
                  // List<Article> articles =
                  //     querySnapshot.docs.map((doc) => doc.data()).toList();
                  List<Article> articles = snapshot.data!.docs.map((doc) {
                    Map<String, dynamic> data =
                        doc.data() as Map<String, dynamic>;
                    return Article.fromJson(
                        data); // Assuming you have a method to convert map to Article object
                  }).toList();

                  return Expanded(
                    child: ListView.builder(
                      itemCount: articles.length,
                      itemBuilder: (context, index) {
                        Article article = articles[index];

                        // String currid = article
                        //     .title!; // Assign an empty string if article.title is null
                        if (article.title == null ||
                            article.urlToImage == null ||
                            article.description == null) return null;
                        return GestureDetector(
                          onLongPress: () {
                            if (article.title == null) {
                            } else {
                              _databaseService.deleteTodo(article);
                              setState(() {});
                            }
                          },
                          onTap: () {
                            _launchUrl(
                              Uri.parse(article.url ?? ""),
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: Color.fromARGB(255, 33, 16, 128))),
                            margin: EdgeInsets.only(bottom: 22),
                            child: Column(children: [
                              Image.network(
                                article.urlToImage ?? PLACEHOLDER_IMAGE_LINK,
                                width: 400,
                                fit: BoxFit.cover,
                              ),
                              GestureDetector(
                                onTap: () {},
                                child: Material(
                                  elevation: 8,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.only(
                                            bottomLeft: Radius.circular(20),
                                            bottomRight: Radius.circular(20))),
                                    padding: EdgeInsets.all(10),
                                    child: Text(
                                      "${article.title}" ?? "",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                            ]),
                          ),
                        );
                      },
                    ),
                  );
                } else if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                } else {
                  return Center(
                      child:
                          CircularProgressIndicator()); // Show loading indicator while data is being fetched
                }
              },
            )
          ],
        ),
      ),
    );
  }
}
