import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:summary/consts.dart';
import 'package:summary/navpages/articleContent.dart';

import '../models/article.dart';

class Search extends StatefulWidget {
  const Search({Key? key}) : super(key: key);

  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  final searchController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool isSearching = false;
  String searchText = '';
  List<Article> searchedArticles = [];
  final Dio dio = Dio();

  Future<void> _searchNews(String searchText) async {
    final response = await dio.get(
      'https://newsapi.org/v2/everything?q=${searchText}&sortBy=publishedAt&language=en&pageSize=10&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      searchedArticles = newsArticle;
      isSearching = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: searchText == ''
              ? Text(
                  "QueryTalks",
                  style: TextStyle(fontFamily: 'Pacifico'),
                )
              : Text(searchText),
          centerTitle: true,
          actions: <Widget>[
            Padding(
                padding: EdgeInsets.only(right: 10),
                child: GestureDetector(
                    onTap: () {
                      setState(() {
                        isSearching = false;
                        searchController.clear();
                      });
                    },
                    child: Icon(Icons.restore_sharp)))
          ],
        ),
        body: Column(children: [
          Container(
            height: 170,
            child: Form(
                key: _formKey,
                child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 20, horizontal: 30),
                    child: ListView(children: [
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 10.0),
                        child: TextFormField(
                          autofocus: false,
                          decoration: const InputDecoration(
                            labelText: 'Smart Search ',
                            labelStyle: TextStyle(fontSize: 20.0),
                            border: OutlineInputBorder(),
                            errorStyle: TextStyle(
                                color: Colors.redAccent, fontSize: 15),
                          ),
                          controller: searchController,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please Enter valid query';
                            }
                            return null;
                          },
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromARGB(255, 5, 23, 66),
                        ),
                        onPressed: () {
                          // Validate returns true if the form is valid, otherwise false.
                          if (_formKey.currentState!.validate()) {
                            setState(() {
                              searchText = searchController.text;
                              isSearching = true;
                              _searchNews(searchText);
                            });
                          }
                        },
                        child: const Text(
                          'Search',
                          style: TextStyle(fontSize: 18.0, color: Colors.white),
                        ),
                      ),
                    ]))),
          ),
          !isSearching
              ? Expanded(
                  child: ListView.builder(
                    shrinkWrap: true, // Add this line
                    itemCount: searchedArticles.length,
                    itemBuilder: (context, index) {
                      final article = searchedArticles[index];
                      return ListTile(
                        onTap: () {
                          // _launchUrl(
                          //   Uri.parse(article.url ?? ""),
                          // );
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  articleContent(article: article),
                            ),
                          );
                        },
                        leading: Container(
                          height: 140,
                          width: 90,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(
                                7), // Half of width or height to create a circle
                            child: Hero(
                              tag: 'articleImage${article.title}',
                              child: Image.network(
                                article.urlToImage ?? PLACEHOLDER_IMAGE_LINK,
                                height: 140,
                                width: 90,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        title: Text(
                          article.title ?? "",
                          style: TextStyle(fontSize: 12),
                        ),
                        subtitle: Text(
                          article.publishedAt ?? "",
                          style: TextStyle(fontSize: 10),
                        ),
                      );
                    },
                  ),
                )
              : Center(
                  child: CircularProgressIndicator(),
                )
        ])
        );
  }
}
