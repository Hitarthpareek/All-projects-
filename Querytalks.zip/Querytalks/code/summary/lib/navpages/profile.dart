import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:summary/consts.dart';

class profilePage extends StatefulWidget {
  const profilePage({key});

  @override
  State<profilePage> createState() => _profilePageState();
}

class _profilePageState extends State<profilePage> {
  @override
  Widget build(BuildContext context) {
    TextEditingController _textEditingController = TextEditingController();

    final user = FirebaseAuth.instance.currentUser;

    // Name, email address, and profile photo URL
    var name = user!.displayName;
    var email = user.email;
    var photoUrl = user.photoURL;

    void updateName(String? updatedname) async {
      FirebaseAuth auth = FirebaseAuth.instance;
      User? user = auth.currentUser;
      await user!.updateDisplayName(updatedname);
    }

    void sendPasswordResetEmail() async {
      try {
        FirebaseAuth auth = FirebaseAuth.instance;
        User? user = auth.currentUser;

        if (user != null) {
          await auth.sendPasswordResetEmail(email: user.email!);
          print('Password reset email sent to ${user.email}');
        } else {
          print('No user is currently logged in.');
        }
      } catch (e) {
        print('An error occurred while sending the password reset email: $e');
      }
    }

    File? _imageFile;
    String? _imageUrl =
        "https://www.prajwaldesai.com/wp-content/uploads/2021/02/Find-Users-Last-Logon-Time-using-4-Easy-Methods.jpg";

    final picker = ImagePicker();

    // Function to pick image from gallery
    Future<void> getImage() async {
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      setState(() {
        if (pickedFile != null) {
          _imageFile = File(pickedFile.path);
        } else {
          print('No image selected.');
        }
      });
    }

    // Future<void> uploadImageToFirebase() async {
    //   if (_imageFile == null) return;

    //   try {
    //     // Get the current user's ID
    //     final String userId = user.uid;

    //     // Create a reference to the location you want to upload to in Firebase Storage
    //     final Reference firebaseStorageRef =
    //         FirebaseStorage.instance.ref().child('user_profile_images/$userId');

    //     // Upload the file to Firebase Storage
    //     await firebaseStorageRef.putFile(_imageFile!);

    //     // Get the download URL of the uploaded image
    //     final String imageUrl = await firebaseStorageRef.getDownloadURL();

    //     setState(() {
    //       _imageUrl = imageUrl;
    //     });
    //   } catch (e) {
    //     print('Error uploading image to Firebase Storage: $e');
    //   }
    // }

    _showDialog(BuildContext context) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            // title: Text('Enter Name'),
            content: TextField(
              controller: _textEditingController,
              decoration: InputDecoration(
                hintText: 'Enter name',
              ),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () {
                  String newname = _textEditingController.text;
                  // Do something with the entered name
                  updateName(newname);
                  setState(() {
                    name = newname;
                  });
                  Navigator.of(context).pop();

                  // Show SnackBar here
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }

    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          centerTitle: true,
          title: Text(
            "Profile",
            style: TextStyle(fontFamily: 'Pacifico', fontSize: 28),
          ),
        ),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                SizedBox(
                  height: 10,
                ),
                // Center(
                //     child: ClipOval(
                //   child: Image.asset(
                //     'assets/bk1.webp',
                //     height: 150,
                //     width: 150,
                //     fit: BoxFit.cover,
                //   ),
                // )),
                Stack(
                  children: <Widget>[
                    Center(
                      child: ClipOval(
                        child: Image.network(
                          _imageUrl ?? PLACEHOLDER_IMAGE_LINK,
                          height: 150,
                          width: 150,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Positioned(
                        bottom: 0,
                        left: 170,
                        child: RawMaterialButton(
                          onPressed: () async {
                            getImage();
                            //uploadImageToFirebase();
                          },
                          elevation: 2.0,
                          fillColor: Colors.white,
                          child: Icon(
                            Icons.edit,
                            size: 25.0,
                          ),
                          // padding: EdgeInsets.all(15.0),
                          shape: CircleBorder(),
                        ))
                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(top: 15, bottom: 2),
                  child: Center(
                    child: Text(
                      name ?? "",
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Center(child: Text(user.email ?? "")),

                SizedBox(
                  height: 50,
                ),

                Center(
                  child: Container(
                      width: 450,
                      child: ListTile(
                        splashColor: Color.fromARGB(255, 201, 216, 229),
                        contentPadding: EdgeInsets.only(right: 10),
                        leading: RawMaterialButton(
                          onPressed: () {},
                          elevation: 2.0,
                          fillColor: Color.fromARGB(255, 221, 234, 254),
                          child: Icon(
                            Icons.edit,
                            size: 25.0,
                            color: const Color.fromARGB(255, 0, 66, 120),
                          ),
                          // padding: EdgeInsets.all(15.0),
                          shape: CircleBorder(),
                        ), // Edit icon
                        title: Text(
                          'Edit Name',
                          style: TextStyle(fontSize: 13),
                        ), // Middle text
                        trailing: Icon(
                          Icons.arrow_forward_ios,
                          size: 17,
                          color: Color.fromARGB(255, 0, 61, 111),
                        ), // Arrow forward icon
                        onTap: () {
                          // Add your onTap functionality here
                          // This function will be called when the ListTile is tapped
                          _showDialog(context);
                        },
                      )),
                ),

                Center(
                  child: Container(
                      width: 450,
                      child: ListTile(
                        splashColor: Color.fromARGB(255, 201, 216, 229),
                        contentPadding: EdgeInsets.only(right: 10),
                        leading: RawMaterialButton(
                          onPressed: () {},
                          elevation: 2.0,
                          fillColor: Color.fromARGB(255, 221, 234, 254),
                          child: Icon(
                            Icons.restore,
                            size: 25.0,
                            color: const Color.fromARGB(255, 0, 66, 120),
                          ),
                          // padding: EdgeInsets.all(15.0),
                          shape: CircleBorder(),
                        ), // Edit icon
                        title: Text(
                          'Reset Password',
                          style: TextStyle(fontSize: 13),
                        ), // Middle text
                        trailing: Icon(
                          Icons.arrow_forward_ios,
                          size: 17,
                          color: Color.fromARGB(255, 0, 61, 111),
                        ), // Arrow forward icon
                        onTap: () {
                          // Add your onTap functionality here
                          // This function will be called when the ListTile is tapped
                          sendPasswordResetEmail();
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content:
                                  Text('Password reset link sent to your mail'),
                              behavior: SnackBarBehavior.floating,
                              duration: Duration(seconds: 3),
                            ),
                          );
                        },
                      )),
                ),

                Center(
                  child: Container(
                      width: 450,
                      child: ListTile(
                        splashColor: Color.fromARGB(255, 201, 216, 229),
                        contentPadding: EdgeInsets.only(right: 10),
                        leading: RawMaterialButton(
                          onPressed: () {},
                          elevation: 2.0,
                          fillColor: Color.fromARGB(255, 221, 234, 254),
                          child: Icon(
                            Icons.delete_forever,
                            size: 25.0,
                            color: const Color.fromARGB(255, 0, 66, 120),
                          ),
                          // padding: EdgeInsets.all(15.0),
                          shape: CircleBorder(),
                        ), // Edit icon
                        title: Text(
                          'Delete Profile',
                          style: TextStyle(fontSize: 13),
                        ), // Middle text
                        trailing: Icon(
                          Icons.arrow_forward_ios,
                          size: 17,
                          color: Color.fromARGB(255, 0, 61, 111),
                        ), // Arrow forward icon
                        onTap: () {
                          // Add your onTap functionality here
                          // This function will be called when the ListTile is tapped
                        },
                      )),
                ),

                Center(
                  child: Container(
                      width: 450,
                      child: ListTile(
                        splashColor: Color.fromARGB(255, 201, 216, 229),
                        contentPadding: EdgeInsets.only(right: 10),
                        leading: RawMaterialButton(
                          onPressed: () {},
                          elevation: 2.0,
                          fillColor: Color.fromARGB(255, 221, 234, 254),
                          child: Icon(
                            Icons.logout,
                            size: 25.0,
                            color: const Color.fromARGB(255, 0, 66, 120),
                          ),
                          // padding: EdgeInsets.all(15.0),
                          shape: CircleBorder(),
                        ), // Edit icon
                        title: Text(
                          'LogOut',
                          style: TextStyle(fontSize: 13),
                        ), // Middle text
                        trailing: Icon(
                          Icons.arrow_forward_ios,
                          size: 17,
                          color: Color.fromARGB(255, 0, 61, 111),
                        ), // Arrow forward icon
                        onTap: () {
                          // Add your onTap functionality here
                          // This function will be called when the ListTile is tapped
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: Text(
                                  'Logout',
                                  style: TextStyle(fontFamily: 'Pacifico'),
                                ),
                                content: Text(
                                    'Do you want to proceed with this action?'),
                                actions: <Widget>[
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text('Cancel'),
                                  ),
                                  ElevatedButton(
                                    onPressed: () {
                                      // Add your functionality here when user confirms
                                      FirebaseAuth.instance.signOut();

                                      Navigator.pushNamed(context, "/login");
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          content:
                                              Text('Logged Out Successfully'),
                                          behavior: SnackBarBehavior.floating,
                                          duration: Duration(seconds: 3),
                                        ),
                                      );
                                    },
                                    child: Text('Yes'),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      )),
                )
              ],
            ),
          ),
        ));
  }
}
