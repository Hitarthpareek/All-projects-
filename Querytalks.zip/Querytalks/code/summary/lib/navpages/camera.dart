import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:http/http.dart' as http;
import 'package:translator/translator.dart';

class CameraPage extends StatelessWidget {
  const CameraPage({key});

  @override
  Widget build(BuildContext context) {
    return Summary();
  }
}

class Summary extends StatefulWidget {
  @override
  State<Summary> createState() => _SummaryState();
}

class _SummaryState extends State<Summary> {
  String dropdownvalue = 'English';

  // List of items in our dropdown menu
  var items = [
    'English',
    'Hindi',
    'Tamil',
  ];
  String translated = '';

  String mytext = '';
  bool scanning = false;
  XFile? image;
  bool sumorscan = false;

  // final TexinputText = TextEditingController();
  final TextEditingController suggestion = TextEditingController();

  final apiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=AIzaSyB8B4g4U9V0rktuznItJdifAAtZO042f0c';

  final headers = {
    'Content-Type': 'application/json',
  };

  void translate(String desti) async {
    GoogleTranslator translate = new GoogleTranslator();
    var translation = await translate.translate(mytext, from: 'en', to: desti);
    setState(() {
      translated = translation.text.toString();
    });
  }

  String getlanguagecode(String lan) {
    if (lan == 'English')
      return "en";
    else if (lan == 'Hindi')
      return 'hi';
    else if (lan == 'Tamil') return 'ta';
    return '--';
  }

  getdata() async {
    setState(() {
      scanning = true;
    });

    var data = {
      "contents": [
        {
          "parts": [
            {'text': "$suggestion.text - $mytext"}
          ]
        }
      ],
    };

    await http
        .post(Uri.parse(apiUrl), headers: headers, body: jsonEncode(data))
        .then((response) {
      if (response.statusCode == 200) {
        var result = jsonDecode(response.body);

        print(result['candidates'][0]['content']['parts'][0]['text']);

        setState(() {
          mytext = result['candidates'][0]['content']['parts'][0]['text'];
        });
      } else {
        print("request failed with status: ${response.statusCode}");
      }
    }).catchError((error) {
      print('Error : $error');
    });

    setState(() {
      scanning = false;
      translated = mytext;
    });
  }

  final ImagePicker picker = ImagePicker();

  getImage(ImageSource ourSource) async {
    XFile? result = await picker.pickImage(source: ourSource);
    if (result != null) {
      setState(() {
        image = result;
      });
      performTextRecognition();
    }
  }

  performTextRecognition() async {
    setState(() {
      scanning = true;
    });
    try {
      final inputImage = InputImage.fromFilePath(image!.path);
      final textRecognizer = GoogleMlKit.vision.textRecognizer();
      final recognizedText = await textRecognizer.processImage(inputImage);

      setState(() {
        mytext = recognizedText.text;
        translated = mytext;
        if (sumorscan) getdata();
      });
      textRecognizer.close();
    } catch (e) {
      print('Error during text recognition: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Scanner",
          style: TextStyle(fontFamily: 'Pacifico', fontSize: 28),
        ),
        actions: <Widget>[
          DropdownButton(
            padding: EdgeInsets.all(8),

            // Initial Value
            value: dropdownvalue,

            // Down Arrow Icon
            icon: const Icon(Icons.keyboard_arrow_down),

            // Array list of items
            items: items.map((String items) {
              return DropdownMenuItem(
                value: items,
                child: Text(items),
              );
            }).toList(),
            // After selecting the desired option,it will
            // change button value to selected value
            onChanged: (String? newValue) {
              setState(() {
                dropdownvalue = newValue!;
                translate(getlanguagecode(dropdownvalue));
              });
            },
          ),
        ],
      ),
      body: ListView(
        shrinkWrap: true,
        children: [
          image == null
              ? Center(
                  child: Container(
                    decoration: BoxDecoration(
                        image: DecorationImage(
                      image: AssetImage(
                          sumorscan ? 'assets/s1.png' : 'assets/c1.png'),
                    )),
                    height: 400,

                    // decoration: BoxDecoration(),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 30),
                    child: Container(),
                  ),
                )
              : Center(
                  child: Image.file(
                    File(image!.path),
                    height: 400,
                  ),
                ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor:
                            const Color.fromARGB(255, 255, 255, 255)),
                    onPressed: () {
                      getImage(ImageSource.gallery);
                    },
                    child: const Text(
                      "Gallery",
                      style: TextStyle(color: Color.fromARGB(255, 96, 11, 153)),
                    )),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    shape: const CircleBorder(
                        side: BorderSide(color: Colors.black)),
                    backgroundColor: Colors.white),
                onPressed: () {
                  setState(() {
                    image = null;
                    mytext = '';
                    translated = '';
                    suggestion.clear();
                  });
                },
                child: const Icon(
                  Icons.restart_alt,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor:
                            const Color.fromARGB(255, 255, 255, 255)),
                    onPressed: () {
                      getImage(ImageSource.camera);
                    },
                    child: const Text(
                      "Camera",
                      style: TextStyle(color: Color.fromARGB(255, 96, 11, 153)),
                    )),
              )
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                sumorscan = !sumorscan;
                image = null;
                mytext = '';
                translated = '';
              });
            },
            child: Material(
              elevation: 10,
              child: Container(
                margin: const EdgeInsets.only(left: 20, right: 20),
                padding: const EdgeInsets.only(top: 13, bottom: 13),
                decoration: BoxDecoration(
                    //color: const Color.fromARGB(255, 191, 46, 46),
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: Text(
                    !sumorscan
                        ? 'Scanning only ! Tap to switch to summarize !'
                        : "Summarizing Text ! Tap to switch to Scan",
                    style:
                        const TextStyle(color: Color.fromARGB(255, 70, 3, 121)),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          image != null
              ? Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Center(
                    child: Text(
                      sumorscan ? "Summary" : "Scanned Text",
                      style: const TextStyle(
                          color: Color.fromARGB(255, 47, 4, 87),
                          fontSize: 20,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                )
              : Container(),
          sumorscan
              ? Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: TextField(
                    controller: suggestion,
                    maxLines: 1,
                    decoration: const InputDecoration(
                        hintText: 'First Enter ! In how many words....'),
                  ),
                )
              : GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: translated));
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Copied to clipboard')));
                  },
                  child: Container(
                      padding: const EdgeInsets.all(20),
                      child: Text(translated)),
                ),
          sumorscan && !scanning
              ? GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: translated));
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Copied to clipboard')));
                  },
                  child: Container(
                      padding: const EdgeInsets.all(20),
                      child: Text(translated)),
                )
              : Container(),
          sumorscan
              ? scanning
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : Container()
              : Container()
        ],
      ),
    );
  }
}
