
import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:summary/navpages/bookmark.dart';
import 'package:summary/navpages/camera.dart';
import 'package:summary/navpages/home.dart';
import 'package:summary/navpages/profile.dart';

class PreHome extends StatefulWidget {
  PreHome({key});

  @override
  State<PreHome> createState() => _PreHomeState();
}

class _PreHomeState extends State<PreHome> {
  final _pageController = PageController();

  // Future<bool> onWillPop() async {
  //   return (await showDialog(
  //         context: context,
  //         builder: (context) => new AlertDialog(
  //           title: new Text('Are you sure?'),
  //           content: new Text('Do you want to exit an App'),
  //           actions: <Widget>[
  //             TextButton(
  //               onPressed: () => Navigator.of(context).pop(false),
  //               child: new Text('No'),
  //             ),
  //             TextButton(
  //               onPressed: () => Navigator.of(context).pop(true),
  //               child: new Text('Yes'),
  //             ),
  //           ],
  //         ),
  //       )) ??
  //       false;
  // }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          body: PageView(
            controller: _pageController,
            children: <Widget>[Home(), CameraPage(), Bookmark(), profilePage()],
          ),
          bottomNavigationBar: CurvedNavigationBar(
            backgroundColor: Color.fromARGB(255, 235, 60, 60),
            buttonBackgroundColor: Color.fromARGB(255, 255, 255, 255),
            color: Colors.white,
            height: 50,
            items: const <Widget>[
              Icon(
                Icons.home,
                size: 30,
                color: Colors.red,
              ),
              Icon(
                Icons.camera,
                size: 30,
                color: Colors.deepPurpleAccent,
              ),
              Icon(
                Icons.bookmark,
                size: 30,
                color: Colors.green,
              ),
              Icon(
                Icons.person,
                size: 30,
                color: Colors.blue,
              )
            ],
            onTap: (index) {
              _pageController.animateToPage(index,
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOut);
            },
          ),
        ),
      ),
    );
  }
}
