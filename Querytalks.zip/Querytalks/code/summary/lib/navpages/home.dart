import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:summary/consts.dart';
import 'package:summary/models/article.dart';
import 'package:summary/navpages/articleContent.dart';
import 'package:summary/navpages/last30days.dart';
import 'package:summary/navpages/search.dart';
import 'package:url_launcher/url_launcher.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final pagesize = 6;
  final Dio dio = Dio();
  List<Article> generalarticles = [];
  List<Article> techarticles = [];
  List<Article> sportsarticles = [];
  List<Article> businessarticles = [];
  List<Article> healtharticles = [];
  List<Article> sciencesarticles = [];
  List<Article> entertainarticles = [];

  Future<void> _getbussinessNews(int pagesize) async {
    final response = await dio.get(
      'https://newsapi.org/v2/top-headlines?country=in&category=business&pageSize=${pagesize}&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      businessarticles = newsArticle;
    });
  }

  Future<void> _getentertainNews(int pagesize) async {
    final response = await dio.get(
      'https://newsapi.org/v2/top-headlines?country=in&category=entertainment&pageSize=${pagesize}&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      entertainarticles = newsArticle;
    });
  }

  Future<void> _getgeneralNews(int pagesize) async {
    final response = await dio.get(
      'https://newsapi.org/v2/top-headlines?country=in&category=general&pageSize=${pagesize}&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      generalarticles = newsArticle;
    });
  }

  Future<void> _gethealthNews(int pagesize) async {
    final response = await dio.get(
      'https://newsapi.org/v2/top-headlines?country=in&category=science&pageSize=${pagesize}&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      sciencesarticles = newsArticle;
    });
  }

  Future<void> _getscienceNews(int pagesize) async {
    final response = await dio.get(
      'https://newsapi.org/v2/top-headlines?country=in&category=health&pageSize=${pagesize}&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      healtharticles = newsArticle;
    });
  }

  Future<void> _getsportsNews(int pagesize) async {
    final response = await dio.get(
      'https://newsapi.org/v2/top-headlines?country=in&category=sports&pageSize=${pagesize}&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      sportsarticles = newsArticle;
    });
  }

  Future<void> _gettechNews(int pagesize) async {
    final response = await dio.get(
      'https://newsapi.org/v2/top-headlines?country=in&category=technology&pageSize=${pagesize}&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      techarticles = newsArticle;
    });
  }

  Future<void> _launchUrl(Uri url) async {
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  void initState() {
    super.initState();
    _getgeneralNews(pagesize);
    _gettechNews(pagesize);
    _getsportsNews(pagesize);
    _getbussinessNews(pagesize);
    _getentertainNews(pagesize);
    _getscienceNews(pagesize);
    _gethealthNews(pagesize);
  }

  final PageController pageController = PageController();

  int selectedIndex = 0;
  String url = '';
  var data;
  bool tapped_now = false;
  List<String> stringList = [];
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () {
            // Add your onPressed code here!
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => last30days()));
          },
          label: Text(
            'Last 7 days',
            style: TextStyle(color: Color.fromARGB(255, 239, 234, 255)),
          ),
          icon: Icon(
            Icons.newspaper,
            color: Colors.white,
          ),
          backgroundColor: Color.fromARGB(255, 21, 5, 62),
        ),
        appBar: AppBar(
          actions: <Widget>[
            IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.black,
              ),
              onPressed: () {
                // do something
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Search(),
                  ),
                );
              },
            )
          ],
          centerTitle: true,
          title: Text(
            "QueryTalks",
            style: TextStyle(fontFamily: 'Pacifico', fontSize: 26),
          ),
        ),
        backgroundColor: Color.fromARGB(255, 240, 240, 240),
        body: Container(
          padding: EdgeInsets.all(20),
          child: Column(children: [
            // use this to input query
            // TextField(
            //   decoration: InputDecoration(
            //       hintText: "Enter topic",
            //       suffixIcon: IconButton(
            //         icon: Icon(Icons.send),
            //         onPressed: () async {
            //           setState(() {
            //             tapped_now = true;
            //           });
            //           data = await fetchdata(url);
            //           var decoded = jsonDecode(data);
            //           print(decoded);
            //           setState(() {
            //             stringList = List<String>.from(
            //                 decoded.map((item) => item.toString()));
            //             tapped_now = false;
            //           });
            //         },
            //       )),
            //   onChanged: (value) {
            //     url = 'http://10.0.2.2:5000/api?query=' + value.toString();
            //   },
            // ),

            //   Expanded(child:
            //   ListView.builder(
            //   itemCount: stringList.length,
            //   itemBuilder: (BuildContext context, int index) {
            //     return ListTile(
            //       title: Text(stringList[index]),
            //       onTap: () {
            //         // Add onTap functionality here if needed
            //       },
            //     );
            //   },
            // ),
            //   ),
            SingleChildScrollView(
              // controller: pageController,
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  buildItem("Trending", 0),
                  buildItem("Tech", 1),
                  buildItem("Sports", 2),
                  buildItem("Bussiness", 3),
                  buildItem("Science", 4),
                  buildItem("Health", 5),
                  buildItem("Entertainment", 6),
                ],
              ),
            ),

            Expanded(
              child: Container(
                child: Column(
                  children: [
                    Expanded(
                      child: PageView(
                        controller: pageController,
                        onPageChanged: (index) {
                          setState(() {
                            selectedIndex = index;
                          });
                        },
                        children: [
                          buildCard("assets/trend.webp", generalarticles),
                          buildCard("assets/pic.jpg", techarticles),
                          buildCard("assets/sports.jpg", sportsarticles),
                          buildCard("assets/bussiness.webp", businessarticles),
                          buildCard("assets/science.webp", sciencesarticles),
                          buildCard("assets/health.jpg", healtharticles),
                          buildCard("assets/entertain.jpg", entertainarticles),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // child: Card(
              //   elevation: 20,
              //   shadowColor: Colors.black,
              //   color: Color.fromARGB(255, 247, 247, 247),
              //   child: SingleChildScrollView(
              //     child: Container(
              //       // width: 300,
              //       height: 830,
              //       child: Column(
              //         children: [
              //           Container(
              //             height: 200,
              //             decoration: BoxDecoration(
              //               borderRadius:
              //                   BorderRadius.vertical(top: Radius.circular(10)),
              //               image: DecorationImage(
              //                 image: AssetImage('assets/pic.jpg'),
              //                 fit: BoxFit.cover,
              //               ),
              //             ),
              //           ),

              //           SizedBox(
              //             height: 10,
              //           ),

              //           Flexible(
              //             child: Padding(
              //               padding: const EdgeInsets.symmetric(horizontal: 8.0),
              //               child: SingleChildScrollView(
              //                 child: Text(
              //                   "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).p publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)",
              //                   textAlign: TextAlign
              //                       .justify, // Optionally set text alignment
              //                 ),
              //               ),
              //             ),
              //           ),

              //           Row(
              //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //             children: [
              //               Padding(
              //                 padding: const EdgeInsets.only(left: 20.0),
              //                 child: ElevatedButton(
              //                     style: ButtonStyle(
              //                       minimumSize: MaterialStateProperty.all<Size>(
              //                         Size(5,
              //                             35), // Adjust width and height as needed
              //                       ),
              //                     ),
              //                     onPressed: () {},
              //                     child: Text("Previous")),
              //               ),
              //               Padding(
              //                 padding: const EdgeInsets.only(right: 30.0),
              //                 child: ElevatedButton(
              //                     style: ButtonStyle(
              //                       minimumSize: MaterialStateProperty.all<Size>(
              //                         Size(5,
              //                             35), // Adjust width and height as needed
              //                       ),
              //                     ),
              //                     onPressed: () {},
              //                     child: Text("Next")),
              //               ),
              //               Padding(
              //                 padding: const EdgeInsets.only(right: 20.0),
              //                 child: Icon(
              //                   Icons.bookmark_add,
              //                 ),
              //               ),
              //             ],
              //           ),

              //           !tapped_now
              //               ? Expanded(
              //                   child: ListView.builder(
              //                     itemCount: stringList.length,
              //                     itemBuilder: (BuildContext context, int index) {
              //                       return ListTile(
              //                         title: Text(stringList[index]),
              //                         onTap: () {
              //                           // Add onTap functionality here if needed
              //                         },
              //                       );
              //                     },
              //                   ),
              //                 )
              //               : Text(".............Processing................."),

              //           //Text
              //           const SizedBox(
              //             height: 10,
              //           ), //SizedBox
              //         ],
              //       ), //Padding
              //     ),
              //   ), //SizedBox
              // ),
            ),

            // reset logic
            // TextButton(
            //   onPressed: () async {
            //     setState(() {
            //       tapped_now = false;
            //       stringList = [];
            //     });
            //   },
            //   child: Text(
            //     'Tap to reset',
            //     style: TextStyle(fontSize: 20),
            //   ),
            // ),
          ]),
        ),
      ),
    );
  }

  Widget buildItem(String label, int index) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedIndex = index;
          pageController.animateToPage(
            selectedIndex,
            duration: Duration(milliseconds: 500),
            curve: Curves.easeInOut,
          );
        });
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        padding: EdgeInsets.only(left: 20, right: 20, top: 9, bottom: 9),
        margin: EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: selectedIndex == index
              ? Color.fromARGB(255, 235, 60, 60)
              : Colors.white,
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selectedIndex == index
                ? Colors.white
                : Color.fromARGB(255, 124, 124, 124),
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  Widget buildCard(String imagePath, List<Article> trendarticles) {
    return Card(
      shadowColor: Color.fromARGB(255, 168, 163, 219),
      //    color: Color.fromARGB(255, 247, 247, 247),
      child: Column(
        children: [
          Container(
            height: 200,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
              image: DecorationImage(
                image: AssetImage(imagePath),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(height: 10),
          Expanded(
            child: ListView.builder(
              shrinkWrap: true, // Add this line
              itemCount: trendarticles.length,
              itemBuilder: (context, index) {
                final article = trendarticles[index];
                return ListTile(
                  onTap: () {
                    // _launchUrl(
                    //   Uri.parse(article.url ?? ""),
                    // );
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => articleContent(article: article),
                      ),
                    );
                  },
                  leading: Container(
                    height: 140,
                    width: 90,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(
                          7), // Half of width or height to create a circle
                      child: Hero(
                        tag: 'articleImage${article.title}',
                        child: Image.network(
                          article.urlToImage ?? PLACEHOLDER_IMAGE_LINK,
                          height: 140,
                          width: 90,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  title: Text(
                    article.title ?? "",
                    style: TextStyle(fontSize: 12),
                  ),
                  subtitle: Text(
                    article.publishedAt ?? "",
                    style: TextStyle(fontSize: 10),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
