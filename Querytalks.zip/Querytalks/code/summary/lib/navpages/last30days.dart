import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:summary/consts.dart';
import 'package:summary/models/article.dart';
import 'package:summary/navpages/articleContent.dart';

import 'package:pdf/widgets.dart' as pw;
import 'package:http/http.dart' as http;

class PDFGenerator {
  static String _getFirst100Words(String content) {
    final words = content.split(' ');
    if (words.length <= 100) {
      return content;
    } else {
      return words.sublist(0, 100).join(' ');
    }
  }

  static Future<String> generatePDF(List<Article> articles) async {
    final pdf = pw.Document();
    for (var article in articles) {
      final imageBytes = await http
          .get(Uri.parse(article.urlToImage!))
          .then((response) => response.bodyBytes);
      final first100Words = _getFirst100Words(article.content ?? '');
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) {
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  article.title!,
                  style: pw.TextStyle(fontSize: 20),
                ),
                pw.SizedBox(height: 10),
                pw.Container(
                  alignment: pw.Alignment.center,
                  child: pw.Image(
                    pw.MemoryImage(imageBytes),
                  ),
                ),
                pw.Text(
                  first100Words,
                  style: pw.TextStyle(fontSize: 15),
                ),
              ],
            );
          },
        ),
      );
    }
    final output = await getTemporaryDirectory();
    final file = File("${output.path}/articles.pdf");
    await file.writeAsBytes(await pdf.save());
    return file.path;
  }
}

class last30days extends StatefulWidget {
  const last30days({Key? key}) : super(key: key);

  @override
  State<last30days> createState() => _last30daysState();
}

class _last30daysState extends State<last30days> {
  bool pdfLoading = false;
  final searchController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool isSearching = false;
  String searchText = '';
  List<Article> searchedArticles = [];
  final Dio dio = Dio();

  Future<void> _searchNews(String searchText) async {
    final response = await dio.get(
      'https://newsapi.org/v2/everything?q=${searchText}&from=2024-04-10&to=2024-04-17&sortBy=popularity&pageSize=7&apiKey=${NEWS_API_KEY}',
    );
    final articlesJson = response.data["articles"] as List;
    setState(() {
      List<Article> newsArticle =
          articlesJson.map((a) => Article.fromJson(a)).toList();
      newsArticle = newsArticle.where((a) => a.title != "[Removed]").toList();
      searchedArticles = newsArticle;
      isSearching = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Last 7 days",
          style: TextStyle(fontFamily: 'Pacifico'),
        ),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          setState(() {
            pdfLoading = true;
          });
          // Navigator.push(
          //       context, MaterialPageRoute(builder: (context) => to_pdf(articles: searchedArticles)));
          final pdfPath = await PDFGenerator.generatePDF(searchedArticles);
          OpenFile.open(pdfPath);
          setState(() {
            pdfLoading = false;
          });
        },
        label: Text(
          !pdfLoading ? "To PDF" : "Loading",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Color.fromARGB(255, 10, 1, 53),
        icon: Icon(
          Icons.picture_as_pdf,
          color: Colors.white,
        ),
      ),
      body: Column(children: [
        Container(
          height: 170,
          child: Form(
              key: _formKey,
              child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 20, horizontal: 30),
                  child: ListView(children: [
                    Container(
                      margin: const EdgeInsets.symmetric(vertical: 10.0),
                      child: TextFormField(
                        autofocus: false,
                        decoration: const InputDecoration(
                          labelText: 'Enter keyword',
                          labelStyle: TextStyle(fontSize: 20.0),
                          border: OutlineInputBorder(),
                          errorStyle:
                              TextStyle(color: Colors.redAccent, fontSize: 15),
                        ),
                        controller: searchController,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please Enter valid query';
                          }
                          return null;
                        },
                      ),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 5, 23, 66),
                      ),
                      onPressed: () {
                        // Validate returns true if the form is valid, otherwise false.
                        if (_formKey.currentState!.validate()) {
                          setState(() {
                            searchText = searchController.text;
                            isSearching = true;
                            _searchNews(searchText);
                          });
                        }
                      },
                      child: const Text(
                        'Search',
                        style: TextStyle(fontSize: 18.0, color: Colors.white),
                      ),
                    ),
                  ]))),
        ),
        !isSearching
            ? Expanded(
                child: ListView.builder(
                  shrinkWrap: true, // Add this line
                  itemCount: searchedArticles.length,
                  itemBuilder: (context, index) {
                    final article = searchedArticles[index];
                    return ListTile(
                      onTap: () {
                        // _launchUrl(
                        //   Uri.parse(article.url ?? ""),
                        // );
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                articleContent(article: article),
                          ),
                        );
                      },
                      leading: Container(
                        height: 140,
                        width: 90,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                              7), // Half of width or height to create a circle
                          child: Hero(
                            tag: 'articleImage${article.title}',
                            child: Image.network(
                              article.urlToImage ?? PLACEHOLDER_IMAGE_LINK,
                              height: 140,
                              width: 90,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      title: Text(
                        article.title ?? "",
                        style: TextStyle(fontSize: 12),
                      ),
                      subtitle: Text(
                        article.publishedAt ?? "",
                        style: TextStyle(fontSize: 10),
                      ),
                    );
                  },
                ),
              )
            : Center(
                child: CircularProgressIndicator(),
              )
      ]),
    );
  }
}
