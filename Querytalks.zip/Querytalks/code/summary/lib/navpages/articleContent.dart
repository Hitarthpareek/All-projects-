import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:summary/consts.dart';
import 'package:summary/database_service.dart';
import 'package:summary/models/article.dart';
import 'package:http/http.dart' as http;
import 'package:translator/translator.dart';
import 'package:url_launcher/url_launcher.dart';

class articleContent extends StatefulWidget {
  final Article article;
  const articleContent({Key? key, required this.article}) : super(key: key);

  @override
  State<articleContent> createState() => _articleContentState();
}

class _articleContentState extends State<articleContent> {
  bool isSpeaking = true;
  final FlutterTts flutterTts = FlutterTts();

  speak(String text, String lan) async {
    if (!isSpeaking) {
      await flutterTts.setLanguage(lan);
      await flutterTts.setPitch(1);
      flutterTts.setSpeechRate(0.4);
      await flutterTts.speak(text);
    } else {
      flutterTts.pause();
    }
  }

  String dropdownvalue = 'English';

  // List of items in our dropdown menu
  var items = [
    'English',
    'Hindi',
    'Tamil',
  ];

  String mytext = '';
  String translated = '';
  bool scanning = false;
  XFile? image;
  bool alreadyOnServer = false;

  final DatabaseService _databaseService = DatabaseService();

  final apiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=AIzaSyB8B4g4U9V0rktuznItJdifAAtZO042f0c';

  final headers = {
    'Content-Type': 'application/json',
  };

  getdata() async {
    setState(() {
      scanning = true;
    });

    print(widget.article.content);

    var data = {
      "contents": [
        {
          "parts": [
            {'text': "Summarize in 100 words - ${widget.article.content}"}
          ]
        }
      ],
    };

    await http
        .post(Uri.parse(apiUrl), headers: headers, body: jsonEncode(data))
        .then((response) {
      if (response.statusCode == 200) {
        var result = jsonDecode(response.body);

        print(result['candidates'][0]['content']['parts'][0]['text']);

        setState(() {
          mytext = result['candidates'][0]['content']['parts'][0]['text'];
        });
      } else {
        print("request failed with status: ${response.statusCode}");
      }
    }).catchError((error) {
      print('Error : $error');
    });

    setState(() {
      scanning = false;
      translated = mytext;
    });
  }

  Future<void> _launchUrl(Uri url) async {
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  doesDocumentExist(String? title) async {
    final _firestore = FirebaseFirestore.instance;
    final userId = await _databaseService.getCurrentUserId();
    DocumentSnapshot documentSnapshot =
        await _firestore.collection(userId!).doc(title).get();
    bool iss = documentSnapshot.exists;
    setState(() {
      alreadyOnServer = iss;
    });
    return iss;
  }

  void translate(String desti) async {
    GoogleTranslator translate = new GoogleTranslator();
    var translation = await translate.translate(mytext, from: 'en', to: desti);
    setState(() {
      translated = translation.text.toString();
    });
  }

  String getlanguagecode(String lan) {
    if (lan == 'English')
      return "en";
    else if (lan == 'Hindi')
      return 'hi';
    else if (lan == 'Tamil') return 'ta';
    return '--';
  }

  @override
  void initState() {
    // TODO: implement initState
    if (widget.article.content != null) getdata();
    doesDocumentExist(widget.article.title);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        label: !alreadyOnServer
            ? Text("Add To Bookmark")
            : Text(
                "Bookmarked",
                style: TextStyle(color: Colors.white),
              ),
        backgroundColor: alreadyOnServer ? Colors.green : Colors.white,
        onPressed: () {
          /////////////////////////////////////////
          if (!alreadyOnServer) {
            _databaseService.addTodo(widget.article.title, widget.article);
            setState(() {
              alreadyOnServer = true;
            });
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content:
                    Text('You can remove this bookmark from Bookmark section'),
                behavior: SnackBarBehavior.floating,
                duration: Duration(seconds: 3),
              ),
            );
          }
        },
        icon: !alreadyOnServer
            ? Icon(
                Icons.bookmark_add,
                color: Colors.black,
              )
            : Icon(
                Icons.done,
                color: Colors.white,
              ),
      ),
      backgroundColor: Color.fromARGB(255, 245, 247, 255),
      appBar: AppBar(
        title: Text(
          "Summary",
          style: TextStyle(fontFamily: 'Pacifico'),
        ),
        centerTitle: true,
        actions: <Widget>[
          DropdownButton(
            padding: EdgeInsets.all(8),

            // Initial Value
            value: dropdownvalue,

            // Down Arrow Icon
            icon: const Icon(Icons.keyboard_arrow_down),

            // Array list of items
            items: items.map((String items) {
              return DropdownMenuItem(
                value: items,
                child: Text(items),
              );
            }).toList(),
            // After selecting the desired option,it will
            // change button value to selected value
            onChanged: (String? newValue) {
              setState(() {
                dropdownvalue = newValue!;
                translate(getlanguagecode(dropdownvalue));
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Hero(
            tag: 'articleImage${widget.article.title}',
            child: Image.network(
              widget.article.urlToImage ?? PLACEHOLDER_IMAGE_LINK,
              width: 400,
              fit: BoxFit.cover,
            ),
          ),
          GestureDetector(
            onTap: () {
              _launchUrl(
                Uri.parse(widget.article.url ?? ""),
              );
            },
            child: Material(
              elevation: 8,
              child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(20),
                        bottomRight: Radius.circular(20))),
                padding: EdgeInsets.all(10),
                child: Text(
                  "${widget.article.title}" ?? "",
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Row(children: [
                !scanning
                    ? Padding(
                        padding: EdgeInsets.only(left: 20),
                        child: GestureDetector(
                            onTap: () {
                              setState(() {
                                isSpeaking = !isSpeaking;
                              });
                              speak(
                                  translated == ''
                                      ? 'No summarization available'
                                      : translated,
                                  getlanguagecode(dropdownvalue));
                            },
                            child: isSpeaking
                                ? Icon(Icons.volume_up)
                                : Icon(Icons.pause)),
                      )
                    : Text(""),
                Expanded(
                    child: GestureDetector(
                  onTap: () {
                    !scanning
                        ? Clipboard.setData(ClipboardData(text: mytext))
                        : 5;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Copied to clipboard')),
                    );
                  },
                  child: Container(
                      padding: EdgeInsets.all(15),
                      child: scanning
                          ? Center(child: CircularProgressIndicator())
                          : translated == ''
                              ? Center(
                                  child: Text(
                                  'No Summarization available',
                                  style: TextStyle(fontSize: 14),
                                ))
                              : Text(
                                  translated,
                                  style: TextStyle(fontSize: 14),
                                )),
                )),
              ]),
            ),
          )
        ],
      ),
    );
  }
}
