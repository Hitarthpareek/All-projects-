import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:summary/firebase_options.dart';
import 'package:summary/navpages/forgotpass.dart';
import 'package:summary/navpages/home.dart';
import 'package:summary/navpages/last30days.dart';
import 'package:summary/navpages/prehome.dart';
import 'package:summary/navpages/studentsignup.dart';
import 'package:summary/routes.dart';
import 'package:summary/navpages/search.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  FirebaseFirestore.instance.settings =
      const Settings(persistenceEnabled: true);

  runApp(Login());
}

class Login extends StatelessWidget {
  const Login({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: MaterialApp(
        initialRoute: Myroutes.login,
        routes: {
          Myroutes.login: (context) => Loginpage1(),
          Myroutes.prehome: (context) => PreHome(),
          Myroutes.home: (context) => Home(),
          Myroutes.signup: (context) => SignUp(),
          Myroutes.forgotpassword: (context) => ForgotPass(),
          Myroutes.search: (context) => Search(),
          Myroutes.last30days: (context) => last30days(),
        },
        debugShowCheckedModeBanner: false,
        home: Loginpage1(),
      ),
    );
  }
}

class Loginpage1 extends StatefulWidget {
  Loginpage1({Key? key}) : super(key: key);

  @override
  State<Loginpage1> createState() => _Loginpage1State();
}

class _Loginpage1State extends State<Loginpage1> {
  bool isEmailVerified = false;

  Future sendVerificationMail() async {
    try {
      final user = FirebaseAuth.instance.currentUser!;
      await user.sendEmailVerification();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.orangeAccent,
          content: Text(
            "Verification Mail Sent",
            style: TextStyle(fontSize: 18.0, color: Colors.black),
          ),
        ),
      );
    }
  }

  Future checkEmailVerified(BuildContext context) async {
    await FirebaseAuth.instance.currentUser!.reload();
    bool isveri = FirebaseAuth.instance.currentUser!.emailVerified;
    if (!isveri) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.orangeAccent,
          content: Text(
            "Email Not Verified",
            style: TextStyle(fontSize: 16.0, color: Colors.black),
          ),
        ),
      );
    } else
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => PreHome()));
    setState(() {
      isEmailVerified = isveri;
    });
  }

  var formKey = GlobalKey<FormState>();

  var email = "";
  var password = "";
  // Create a text controller and use it to retrieve the current value
  // of the TextField.
  var emailController = TextEditingController();
  var passwordController = TextEditingController();

  Future<void> signOut() async {
    await FirebaseAuth.instance.signOut();
    // ignore: use_build_context_synchronously
  }

  userLogin(BuildContext context) async {
    try {
      await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password);
      checkEmailVerified(context);
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        print("No User Found for that Email");
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Colors.orangeAccent,
            content: Text(
              "Email Not Found",
              style: TextStyle(fontSize: 16.0, color: Colors.black),
            ),
          ),
        );
      } else if (e.code == 'wrong-password') {
        print("Wrong Password Provided by User");
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Colors.orangeAccent,
            content: Text(
              "Wrong Password",
              style: TextStyle(fontSize: 16.0, color: Colors.black),
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Colors.orangeAccent,
            content: Text(
              "Invalid Credentials",
              style: TextStyle(fontSize: 16.0, color: Colors.black),
            ),
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            elevation: 10,
            title: const Text(
              "Login or SignUp",
              style: TextStyle(fontFamily: 'Pacifico'),
            ),
            centerTitle: true,
            backgroundColor: Colors.white,
          ),
          body: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('assets/bk2.jpg'),
                        fit: BoxFit.cover)),
                // decoration: const BoxDecoration(
                //     gradient: LinearGradient(
                //   begin: Alignment.topRight,
                //   end: Alignment.bottomLeft,
                //   colors: [
                //     Colors.blue,
                //     Colors.red,
                //   ],
                // )
                // ),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                alignment: Alignment.center,
                child: Column(children: [
                  // Image.asset(
                  //   "assets/trend.webp",
                  //   width: 250,
                  //   height: 250,
                  // ),
                  SizedBox(height: 70),
                  Padding(
                    padding: EdgeInsets.only(bottom: 60),
                    child: Text(
                      "QueryTalks",
                      style: TextStyle(
                          shadows: [
                            Shadow(
                              blurRadius: 10.0, // shadow blur
                              color: const Color.fromARGB(
                                  255, 0, 0, 0), // shadow color
                              offset: Offset(2.0, 2.0),
                            )
                          ],
                          fontSize: 55,
                          color: const Color.fromARGB(255, 249, 249, 249),
                          fontFamily: 'Pacifico'),
                    ),
                  ),
                  RoundedInputField1(
                    emailController: emailController,
                    hintText: "Your E-mail",
                    onChanged: (value) {},
                    icon: Icons.person,
                  ),
                  RoundedInputField2(
                    passwordController: passwordController,
                    hintText: "Password",
                    onChanged: (value) {},
                    icon: Icons.lock,
                  ),
                  GestureDetector(
                    onTap: () {
                      // Validate returns true if the form is valid, otherwise false.
                      if (formKey.currentState!.validate()) {
                        setState(() {
                          email = emailController.text;
                          password = passwordController.text;
                        });

                        userLogin(context);

                        // ignore: use_build_context_synchronously
                        //Navigator.pushNamed(context, Myroutes.homepage);

                        //  if (isEmailVerified)
                      }
                    },
                    child: Container(
                      margin: const EdgeInsets.only(top: 40),
                      alignment: Alignment.center,
                      height: 45,
                      width: MediaQuery.of(context).size.width / 1.3,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(7),
                          color: const Color.fromARGB(255, 34, 44, 78)),
                      child: const Text(
                        "Log In",
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            fontSize: 15,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(top: 10),
                    width: MediaQuery.of(context).size.width / 1.3,
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () => //Navigator.pushNamed(
                                //  context, Myroutes.studentsignup),
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => SignUp())),
                            child: const Text(
                              "Sign Up ?",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ForgotPass())),
                            child: const Text(
                              "Forgot Password ?",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ]),
                  )
                ]),
              ),
            ),
          )),
    );
  }
}

class RoundedInputField1 extends StatelessWidget {
  final TextEditingController emailController;
  final String hintText;
  final IconData icon;
  final ValueChanged<String> onChanged;

  const RoundedInputField1({
    Key? key,
    required this.emailController,
    required this.hintText,
    required this.icon,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFieldContainer(
      child: TextFormField(
        controller: emailController,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please Enter Email';
          } else if (!value.contains('@')) {
            return 'Please Enter Valid Email';
          }
          return null;
        },
        obscureText: false,
        onChanged: onChanged,
        decoration: InputDecoration(
            icon: Icon(
              icon,
              color: const Color.fromARGB(255, 34, 44, 78),
            ),
            hintText: hintText,
            border: InputBorder.none),
      ),
    );
  }
}

class RoundedInputField2 extends StatelessWidget {
  final TextEditingController passwordController;
  final String hintText;
  final IconData icon;
  final ValueChanged<String> onChanged;

  const RoundedInputField2({
    Key? key,
    required this.passwordController,
    required this.hintText,
    required this.icon,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFieldContainer(
      child: TextFormField(
        controller: passwordController,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please Enter Password';
          }
          return null;
        },
        obscureText: true,
        onChanged: onChanged,
        decoration: InputDecoration(
            icon: Icon(
              icon,
              color: const Color.fromARGB(255, 34, 44, 78),
            ),
            hintText: hintText,
            border: InputBorder.none),
      ),
    );
  }
}

class TextFieldContainer extends StatelessWidget {
  final Widget child;
  const TextFieldContainer({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: const EdgeInsets.only(top: 30),
      width: size.width * 0.8,
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 227, 223, 236),
        borderRadius: BorderRadius.circular(28),
      ),
      child: child,
    );
  }
}
