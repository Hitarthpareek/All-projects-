const String NEWS_API_KEY = "b28e7a5b40b14df28bf6f22b79ff199a";

const String PLACEHOLDER_IMAGE_LINK =
    "https://developers.elementor.com/docs/assets/img/elementor-placeholder-image.png";
