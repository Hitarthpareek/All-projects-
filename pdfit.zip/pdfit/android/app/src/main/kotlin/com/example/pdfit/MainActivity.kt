package com.example.pdfit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
