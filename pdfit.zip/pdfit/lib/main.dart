import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:open_file/open_file.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:external_path/external_path.dart'; // Add this import
import 'package:intl/intl.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ImagePickerToPDF(),
    );
  }
}

class ImagePickerToPDF extends StatefulWidget {
  @override
  _ImagePickerToPDFState createState() => _ImagePickerToPDFState();
}

class _ImagePickerToPDFState extends State<ImagePickerToPDF> {
  bool tapped = false;
  var pdf = pw.Document();
  final picker = ImagePicker();
  List<File> images = [];
  bool isSavingPdf = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color.fromARGB(255, 6, 87, 94),
        onPressed: () {
          setState(() {
            images = []; // Clear the images list
            pdf = pw.Document(); // Reset the PDF document
            tapped = false;
          });
        },
        child: const Icon(
          Icons.refresh,
          color: Colors.white,
        ),
      ),
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'PDF Maker',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(255, 6, 87, 94),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            images.isEmpty
                ? ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 6, 87, 94)),
                    child: Text(
                      'Pick Images',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () async {
                      final pickedFiles = await picker.pickMultiImage();
                      if (pickedFiles != null) {
                        setState(() {
                          images =
                              pickedFiles.map((e) => File(e.path)).toList();
                        });
                      }
                    },
                  )
                : const Text(""),
            images.isNotEmpty
                ? !tapped
                    ? ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Color.fromARGB(255, 6, 87, 94)),
                        child: const Text(
                          'Create PDF',
                          style: TextStyle(color: Colors.white),
                        ),
                        onPressed: () async {
                          setState(() {
                            isSavingPdf = true;
                            tapped = true;
                          });

                          for (var image in images) {
                            final imageBytes = await image.readAsBytes();
                            pdf.addPage(pw.Page(
                              build: (pw.Context context) {
                                return pw.Center(
                                  child: pw.Image(pw.MemoryImage(imageBytes)),
                                );
                              },
                            ));
                          }

                          await savePdf();

                          setState(() {
                            isSavingPdf = false;
                          });
                        },
                      )
                    : Text("")
                : Text(""),
            if (isSavingPdf)
              const CircularProgressIndicator() // Show loading indicator
            else if (images.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: images.length,
                  itemBuilder: (context, index) {
                    return Image.file(images[index]);
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> savePdf() async {
    final output = await ExternalPath.getExternalStoragePublicDirectory(
        ExternalPath.DIRECTORY_DOWNLOADS);
    // Format the current time into a string that can be used as a filename
    String formattedTime = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
    final file = File("$output/$formattedTime.pdf");
    await file.writeAsBytes(await pdf.save());
    print('PDF saved: ${file.path}');

    // Open the saved PDF
    await OpenFile.open(file.path);
  }
}
